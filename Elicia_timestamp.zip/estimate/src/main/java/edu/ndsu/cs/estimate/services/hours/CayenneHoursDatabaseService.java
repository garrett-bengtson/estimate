package edu.ndsu.cs.estimate.services.hours;

import java.util.List;
import java.util.Map;
import org.apache.cayenne.Cayenne;
import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.query.ObjectSelect;
import edu.ndsu.cs.estimate.cayenne.persistent.Hours;
import edu.ndsu.cs.estimate.cayenne.persistent.Task;
import edu.ndsu.cs.estimate.services.database.interfaces.CayenneService;

public class CayenneHoursDatabaseService implements HoursDatabaseService {

    private CayenneService cayenneService;
    private Map<Integer, Hours> hoursMap;

    public CayenneHoursDatabaseService(CayenneService cayenneService) {
        this.cayenneService = cayenneService;
    }

    @Override
    public CayenneService getCayenneService() {
        return cayenneService;
    }

    @Override
    public List<? extends Hours> listAllHoursByTask(Task newTask) {
        return ObjectSelect.query(Hours.class)
                .where(Hours.TASKS.eq(newTask))
                .select(cayenneService.newContext());
    }

    @Override
    public Hours getHours(int PK) {
        // Fetch the Hours object directly from the database
        return Cayenne.objectForPK(cayenneService.newContext(), Hours.class, PK);
    }

    @Override
    public Hours getNewHours() {
        // Create and return a new Hours object in a new context
        return cayenneService.newContext().newObject(Hours.class);
    }

    @Override
    public void deleteHours(int PK) {
        ObjectContext context = cayenneService.newContext();
        Hours hours = Cayenne.objectForPK(context, Hours.class, PK);
        if (hours != null) {
            context.deleteObject(hours);
            context.commitChanges();
        }
        hoursMap.remove(PK);
    }

    @Override
    public void updateHours(Hours hours) {
        // Commit changes to save the updated Hours object to the database
        ObjectContext context = hours.getObjectContext();
        if (context != null) {
            context.commitChanges();
        }
        hoursMap.put(hours.getPK(), hours);  // Optionally update the map as well
    }
}
