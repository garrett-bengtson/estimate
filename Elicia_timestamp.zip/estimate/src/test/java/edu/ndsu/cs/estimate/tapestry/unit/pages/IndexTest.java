package edu.ndsu.cs.estimate.tapestry.unit.pages;

import org.apache.tapestry5.dom.Document;
import org.apache.tapestry5.test.PageTester;
import org.junit.jupiter.api.Test;

import edu.ndsu.cs.estimate.services.AppModule;
import edu.ndsu.cs.estimate.services.QaModule;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class IndexTest {

//    @Test
//    void test() {
//        // given
//        String appPackage = "edu.ndsu.cs.estimate";
//        String appName = "App";
//        PageTester tester = new PageTester(appPackage, appName, "src/main/webapp", AppModule.class, QaModule.class);
//
//        // when
//        Document doc = tester.renderPage("Index");
//
//        // then
//        assertTrue(doc.getElementById("title").getChildMarkup().startsWith("Welcome to Tapestry 5!"));
//    }
}

