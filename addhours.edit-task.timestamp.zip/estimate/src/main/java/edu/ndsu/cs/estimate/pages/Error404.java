package edu.ndsu.cs.estimate.pages;

public class Error404
{

}
