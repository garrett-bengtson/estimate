package edu.ndsu.cs.estimate.unit;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class ClassTest {

    @Test
    void test() {
        assertTrue(true);
    }
}

